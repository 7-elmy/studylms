


// import { Clock, Calendar, FileText, AlertCircle, MoveRight } from "lucide-react";
// import { Link } from "react-router-dom";

// export default function AssignmentSubmission() {
//   return (
//     <div className="max-w-md  p-6 bg-white rounded-lg shadow-md">
//       {/* Header */}
//       <div className="text-center mb-6">
//         <h1 className="text-2xl font-bold text-gray-800 mb-2">Start Assignment</h1>
//         <div className="w-16 h-1 bg-yellow-500 mx-auto"></div>
//       </div>

//       {/* Assignment Info */}
//       <div className="bg-blue-50 p-4 rounded-lg mb-6">
//         <div className="flex items-center justify-between mb-3">
//           <div className="flex items-center">
//             <FileText className="w-5 h-5 text-yellow-600 mr-2" />
//             <span className="font-medium text-gray-700">Questions</span>
//           </div>
//           <span className="bg-blue-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">30</span>
//         </div>

//         <div className="flex items-center justify-between">
//           <div className="flex items-center">
//             <Clock className="w-5 h-5 text-yellow-600 mr-2" />
//             <span className="font-medium text-gray-700">Submission Deadline</span>
//           </div>
//           <div className="flex items-center">
//             <Calendar className="w-5 h-5 text-yellow-600 mr-2" />
//             <span className="text-gray-600">10:00 AM</span>
//           </div>
//         </div>
//       </div>

//       {/* Warning */}
//       <div className="flex items-start bg-yellow-50 p-3 rounded-lg mb-6">
//         <AlertCircle className="w-5 h-5 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
//         <p className="text-sm text-yellow-700">
//           Please note that late submission may affect your final grade
//         </p>
//       </div>

//       {/* Start Button */}
//       <Link to={`/assignmentDetails/1`} className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition duration-200 flex gap-2 items-center justify-center">
//         <span className="ml-2">Start</span>
//        <MoveRight className="w-6 h-6 text-white" />
//       </Link>
//     </div>
//   );
// }


import { Clock, Calendar, FileText, AlertCircle, MoveRight } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";

export default function AssignmentSubmission({ courseDetails }) {
  // Safely access nested data with optional chaining and provide fallbacks
  const lessons = courseDetails?.data?.data?.lessons || [];
  let {i18n}= useTranslation()
  // Format time function
  const formatTime = (dateString) => {
    if (!dateString) return "Not specified";
    
    try {
      const date = new Date(dateString);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch (error) {
      return "Invalid time";
    }
  };

  return (
    <div className="w-full">
      {lessons.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4 w-full">
          {lessons.map((lesson, index) => (
            lesson?.homeworks?.map((assignment) => (
              <div key={`${lesson.id}-${assignment.id}`}>
              {console.log({assignment})}
              
                <div className="w-full p-6 bg-white rounded-lg shadow-md">
                  {/* Header */}
                  <div className="text-center mb-6">
                    <h1 className="text-2xl font-bold text-gray-800 mb-2">
                      {i18n.language =="ar" ? `ابدا الواجب ${assignment.name }` : `Start Assignment ${assignment.name }`}
                     
                    </h1>
                    <div className="w-16 h-1 bg-yellow-500 mx-auto"></div>
                  </div>

                  {/* Assignment Info */}
                  <div className="bg-blue-50 p-4 rounded-lg mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <FileText className="w-5 h-5 text-yellow-600 mr-2" />
                        <span className="font-medium text-gray-700">{i18n.language =="ar"? "الحالة" : "Status"}</span>
                      </div>
                      <span
                        className={`${
                          assignment.status === 0
                            ? "bg-blue-100 text-yellow-800"
                            : "text-green-800 bg-green-100"
                        } px-3 py-1 rounded-full text-sm font-medium`}
                      >
                        
                        {assignment.status === 0 ?  i18n.language=="ar"? "غير مسموح به الان":"Not allowed now" : i18n.language=="en"? "Open": "مسموح به"}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <Clock className="w-5 h-5 text-yellow-600 mr-2" />
                        <span className="font-medium text-gray-700">{i18n.language=="en"? "Submission Deadline" :"وقت التسليم"} </span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-5 h-5 text-yellow-600 mr-2" />
                        <span className="text-gray-600">
                          {formatTime(assignment.deadline) || 100}
                        </span>
                      </div>
                    </div>
                  
                  </div>

               

                  {/* Start Button */}
                  {assignment.status !== 0 && (
                   <Link to={`/assignmentDetails/${assignment.id}`} className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-medium py-3 px-4 rounded-lg transition duration-200 flex gap-2 items-center justify-center">
        <span className="ml-2">{ i18n.language =="ar" ? "ابد" :"Start"}</span>
       <MoveRight className="w-6 h-6 text-white" />
      </Link>
                  )}
                </div>
              </div>
            ))
          ))}
        </div>
      ) : (
        <div className="col-span-full text-center py-10">
          <p className="text-gray-500">{i18n.language=="en"? "No assignments available at this time." :"لا يوجد واجبات متاحة الان"}</p>
        </div>
      )}
    </div>
  );
}